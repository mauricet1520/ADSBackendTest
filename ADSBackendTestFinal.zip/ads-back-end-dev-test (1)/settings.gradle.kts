
rootProject.name = "ADSBackendTest1"

